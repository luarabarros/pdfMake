const express = require('express');
const bodyPaeser = require('body-parser');
const userController = require('./controllers/relatorioController');
const app = express(); 

app.set('view engine', 'ejs');

app.use(bodyPaeser.urlencoded({ extended: false }));

app.get('/', userController.getAllUsers);

app.get('/relatorio/pdf', userController.generatePDF);

//iniciar o servidor
app.listen(3000, () => {
    console.log('servidor rodando na porta 3000');
});